package com.shad.Getting_Started_with_MongoDB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GettingStartedWithMongoDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(GettingStartedWithMongoDbApplication.class, args);
	}

}
